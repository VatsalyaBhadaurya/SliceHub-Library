# SliceHub-Library

SliceHub is a modular backend SDK for building Super Apps consisting of independent "slices" plugged into a central hub. This repository contains the core library (v0.1.0) along with an example slice and usage.

## Features

- FastAPI-based core application
- JWT authentication stub
- Role-based access hooks (planned)
- Modular slice registration system
- SQLAlchemy/PostgreSQL abstraction layer
- Optional Firebase adapter (future)
- WebSocket real-time support
- Extensible slice architecture

## Quick start

```bash
pip install slicehub
```

Example application (`example_main.py`):

```python
from slicehub import SliceHub
from slicehub.services.ride import RideSlice

hub = SliceHub()
hub.enable_auth(secret_key="...")
hub.enable_database(url="postgresql://...")
hub.register_slice(RideSlice())
app = hub.get_app()
```

Run with Uvicorn:

```bash
uvicorn example_main:app --reload
```

## Publishing to PyPI

1. **Prepare metadata** – update `pyproject.toml` version and author info.
2. **Install build tools**:
   ```bash
   pip install --upgrade build twine
   ```
3. **Build distributions**:
   ```bash
   python -m build
   ```
   This produces `dist/slicehub-0.1.0.tar.gz` and `dist/slicehub-0.1.0-py3-none-any.whl`.
4. **Upload to PyPI** (use Test PyPI first if desired):
   ```bash
   twine upload dist/*
   # or for test PyPI:
   twine upload --repository testpypi dist/*
   ```
5. **Tag & push** your Git repository:
   ```bash
   git tag v0.1.0
   git push origin --tags
   ```

> You may create a `~/.pypirc` file with your credentials to avoid entering them repeatedly.

## Next steps

Continue building out auth, database, real-time, and slice templates. Contributions welcome!
